#! /bin/bash
cd /home/pi/pyHPSU-master/HPSU
/usr/bin/python3 web/waterpump/pyHPSUd.py -d PYCAN &